from django.urls import path,include
from . import views


urlpatterns = [
    path('formpage', views.formpage, name='formpage'),
]
