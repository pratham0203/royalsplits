from django.shortcuts import render

# Create your views here.
def formpage(request):
	return render(request,'form/formpage.html')