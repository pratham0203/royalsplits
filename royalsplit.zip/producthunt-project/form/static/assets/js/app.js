document.getElementById('fourth').style.display='none'
document.getElementById('five').style.display='none'
document.getElementById('six').style.display='none'
document.getElementById('seven').style.display='none'
document.getElementById('eight').style.display='none'
document.getElementById('nine').style.display='none'
document.getElementById('ten').style.display='none'
document.getElementById('ele').style.display='none'
document.getElementById('twe').style.display='none'
document.getElementById('a').style.display='none'
document.getElementById('b').style.display='none'
document.getElementById('c').style.display='none'
document.getElementById('d').style.display='none'
document.getElementById('e').style.display='none'
document.getElementById('f').style.display='none'
document.getElementById('g').style.display='none'
document.getElementById('h').style.display='none'


const myFunction21 = () => {
  document.getElementById('AA').style.opacity ="0.2"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("a").style.display ='block';
  document.getElementById("b").style.display ='none'
  document.getElementById("c").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}

const myFunction22 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.2"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("b").style.display ='block'
  document.getElementById("a").style.display ='none'
  document.getElementById("c").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}

const myFunction23 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.2"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("c").style.display ='block'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}
const myFunction24 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.2"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("c").style.display ='none'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='block'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}
const myFunction25 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.2"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("c").style.display ='none'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='block'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}
const myFunction26 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.2"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("c").style.display ='none'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='block'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='none'
}
const myFunction27 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.2"
  document.getElementById('AH').style.opacity ="0.85"

  document.getElementById("c").style.display ='none'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='block'
  document.getElementById('h').style.display='none'
}
const myFunction28 = () => {
  document.getElementById('AA').style.opacity ="0.85"
  document.getElementById('AB').style.opacity ="0.85"
  document.getElementById('AC').style.opacity ="0.85"
  document.getElementById('AD').style.opacity ="0.85"
  document.getElementById('AE').style.opacity ="0.85"
  document.getElementById('AF').style.opacity ="0.85"
  document.getElementById('AG').style.opacity ="0.85"
  document.getElementById('AH').style.opacity ="0.2"

  document.getElementById("c").style.display ='none'
  document.getElementById("a").style.display ='none'
  document.getElementById("b").style.display ='none'
  document.getElementById('d').style.display='none'
  document.getElementById('mainphoto1').style.display='none'
  document.getElementById('e').style.display='none'
  document.getElementById('f').style.display='none'
  document.getElementById('g').style.display='none'
  document.getElementById('h').style.display='block'
}

const myFunction = () => {
    document.getElementById('BA').style.opacity ="0.2"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("first").style.display ='block';
    document.getElementById("second").style.display ='none'
    document.getElementById("third").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  
  const myFunction2 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opacity ="0.2"
    document.getElementById('BC').style.opacity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("second").style.display ='block'
    document.getElementById("first").style.display ='none'
    document.getElementById("third").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none' 
  }
  
  const myFunction3 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opacity ="0.85"
    document.getElementById('BC').style.opacity ="0.2"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='block'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction4 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opacity ="0.85"
    document.getElementById('BC').style.opacity ="0.85"
    document.getElementById('BD').style.opacity ="0.2"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='block'
    document.getElementById('five').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction5 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.2"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='block'
    document.getElementById('six').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction6 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.2"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('six').style.display='block'
    document.getElementById('seven').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction7 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.2"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='block'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction8 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.2"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='block'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction9 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.2"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='block'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction10 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.2"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='block'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='none'
  }
  const myFunction11 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.2"
    document.getElementById('BL').style.opacity ="0.85"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='block'
    document.getElementById('twe').style.display='none'
  }
  const myFunction12 = () => {
    document.getElementById('BA').style.opacity ="0.85"
    document.getElementById('BB').style.opBcity ="0.85"
    document.getElementById('BC').style.opBcity ="0.85"
    document.getElementById('BD').style.opacity ="0.85"
    document.getElementById('BE').style.opacity ="0.85"
    document.getElementById('BF').style.opacity ="0.85"
    document.getElementById('BG').style.opacity ="0.85"
    document.getElementById('BH').style.opacity ="0.85"
    document.getElementById('BI').style.opacity ="0.85"
    document.getElementById('BJ').style.opacity ="0.85"
    document.getElementById('BK').style.opacity ="0.85"
    document.getElementById('BL').style.opacity ="0.2"

    document.getElementById("third").style.display ='none'
    document.getElementById("first").style.display ='none'
    document.getElementById("second").style.display ='none'
    document.getElementById('mainphoto').style.display='none'
    document.getElementById('fourth').style.display='none'
    document.getElementById('five').style.display='none'
    document.getElementById('seven').style.display='none'
    document.getElementById('six').style.display='none'
    document.getElementById('eight').style.display='none'
    document.getElementById('nine').style.display='none'
    document.getElementById('ten').style.display='none'
    document.getElementById('ele').style.display='none'
    document.getElementById('twe').style.display='block'
  }
  
  
  